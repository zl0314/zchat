<!DOCTYPE html>
<html>
<!-- Head -->
<head>
    <title>管理员登录</title>
    <!-- Meta-Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <!-- //Meta-Tags -->
    <!-- Style --> <link rel="stylesheet" href="css/style.css" type="text/css" media="all">
</head>
<!-- //Head -->
<!-- Body -->
<body>

<h1>管理员登录</h1>
<div class="container w3layouts agileits">

<?=$content?>
<div class="clear"></div>

</div>

</body>
<!-- //Body -->

</html>